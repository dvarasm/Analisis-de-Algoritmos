Compilación del código

g++ segmento.cpp -o segmento

Ejecución

/.segmento < p1 // donde p1 es el archivo de prueba 1

/////////****\\\\\\\\\
/*ejemplo archivo de prueba*/ 

10 // numero de M
5 // numero de segmentos
0 2
4 6
2 4 //segmentos
8 10
6 8
